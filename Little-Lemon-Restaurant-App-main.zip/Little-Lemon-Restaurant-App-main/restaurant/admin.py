from django.contrib import admin
from .models import Menu
from .models import Booking

admin.site.register(Booking)
admin.site.register(Menu)